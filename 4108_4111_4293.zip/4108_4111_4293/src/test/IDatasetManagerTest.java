package test;

import static org.junit.Assert.*;


import org.junit.Test;

import server.IDatasetManager; 


public class IDatasetManagerTest {
	public void setUp() throws Exception{
		
	}
	
	public IDatasetManager testIDatasetManager(){
		IDatasetManager va  = testIDatasetManager();
		assertNotNull(va.registerDataset(null, null));
		return va;
	}
	
	@Test
	public IDatasetManager testAddItem() {
		IDatasetManager va = testAddItem();
		assertEquals(0,va.registerDataset(null, null));
		return va;
		
	}
}
