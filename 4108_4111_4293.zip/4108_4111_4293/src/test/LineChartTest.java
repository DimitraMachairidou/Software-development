package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import client.controllers.LineChartPresenter;

public class LineChartTest {
	private  LineChartPresenter lineChartToTest;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
	}
	@Before
	public void setUp() throws Exception {
		lineChartToTest = new LineChartPresenter(null, null, null, null, null);
		
	}
	
	@Test
	public final void testLineChartNull() {
		assertNotNull("After setup, the Line Chart is not null", lineChartToTest);
		
	}
	
	public final void testLineChartNoChartTitle() {
		
		lineChartToTest = new LineChartPresenter(null, null, null, null, null);
		assertNull("test if the constructor prevents creation with null title", lineChartToTest);
		
	}
	
	
}
