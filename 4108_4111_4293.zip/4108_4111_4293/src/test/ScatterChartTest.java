package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import client.controllers.ScatterChartPresenter;

public class ScatterChartTest {
	private ScatterChartPresenter scatterChartToTest;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
	}
	@Before
	public void setUp() throws Exception {
		scatterChartToTest = new ScatterChartPresenter(null, null, null, null, null);
		
	}
	
	@Test
	public final void testScatterChartNull() {
		assertNotNull("After setup, the Scatter Chart is not null", scatterChartToTest);
		
	}
	
	public final void testScatterChartNoChartTitle() {
		
		scatterChartToTest = new ScatterChartPresenter(null, null, null, null, null);
		assertNull("test if the constructor prevents creation with null title", scatterChartToTest);
		
	}
	
	
}