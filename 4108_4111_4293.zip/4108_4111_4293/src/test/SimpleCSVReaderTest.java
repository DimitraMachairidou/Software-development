package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import utils.SimpleCSVReader;

public class SimpleCSVReaderTest {
	private static SimpleCSVReader simpleCSVReaderToTest;

	@Before
	public void setUp() throws Exception {
		
	}
		
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		simpleCSVReaderToTest = new SimpleCSVReader();
	}
		
	@Test
	public static void testSimpleCSVReaderNull() {
		assertNotNull("After setup, the CSV is not null", simpleCSVReaderToTest);
			
	}
		
	
}
