package test;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import client.controllers.TableViewController;

public class TableViewControllerTest {
	private TableViewController tableViewControllerToTest;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	
	}

	@Before
	public void setUp() throws Exception {
		tableViewControllerToTest = new TableViewController((ArrayList<String []>) null,(String []) null);
		
	}

	@Test
	public final void testTableViewControllerNull() {
		assertNotNull("After setup, the Table View Controller is not null", tableViewControllerToTest);
	
	}
	
	@Test
	public final void testTableViewControllerNoHeader() {

		tableViewControllerToTest  = new TableViewController((ArrayList<String []>) null,(Boolean) null);
		assertNull("test if the constructor prevents creation with null header", tableViewControllerToTest);
		
	}

}
