package server;

import java.util.ArrayList;
import java.util.HashMap ;

import utils.*;
public class Dataset<array>{
	
	@SuppressWarnings("unused")
	private String datasetNames;
	private String path;
	ArrayList<String[]> names = new ArrayList<String[]>();
	private HashMap<String,ArrayList<String[]>> pths = new HashMap<String,ArrayList<String[]>>();
	private SimpleCSVReader file  = new SimpleCSVReader();
	
	public Dataset(String fileName , ArrayList<String[]> array1, String fName,String pth){
		this.datasetNames = fileName;
		pths.put(fileName,array1);
		this.path = pth;
		this.datasetNames = fName;
		this. names = file.load(pth);
		pths.put(fName,names);
			
	}
	public String getDatasetProjection1(String fName ){
		return this.path;
	}
	
	public void registerDataset(ArrayList<String[]> array2,String g,ArrayList<String[]> array3) {
		this.names = array2;
		pths.put(g,array3);	
	}
	
	public ArrayList<String[]> receiveArray(String path,String price,String s){
		SimpleCSVReader gelly = new SimpleCSVReader();
		names = gelly.load(path);
		System.out.println(names);
		return pths.values().iterator().next();	
	}
	
	public HashMap<String,ArrayList<String[]>>getDatasetProjection(){
		return pths;
	}

	
}
