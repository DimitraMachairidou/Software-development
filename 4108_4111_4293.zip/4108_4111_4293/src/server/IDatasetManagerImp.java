package server;

import java.util.ArrayList;
import java.util.Arrays;

import utils.SimpleCSVReader;

public class IDatasetManagerImp  implements IDatasetManager {	
	private ArrayList<String> allnames1;
	protected String Dataname;
	protected String pathss;
	
	public IDatasetManagerImp(){
		allnames1 = new ArrayList<String>();
	}
	
	
	public int registerDataset(String datasetName, String canonicalPath) {
		
		for(String w: allnames1){
			if(w == null){
				return -1;
			}else if(contains(w))
				return -10;
			}
			return 0;
			
	}
	private boolean contains(String w) {
		return false;
	}

	
	public String[] retrieveDataset(String datasetName, ArrayList<String[]> data) {
		String[] names3 = null;
		ArrayList<String[]> nms = new ArrayList<String[]>();
		for(String[] t :nms ){
			nms.add(names3);
			if(t == null){
				return null;
			}
		}
		return names3;
		
	}
	
	public int filterDataset(String originalDatasetName,String newDatasetName, String filterColumnName, String filterValue){

	ArrayList<String[]> data = new ArrayList<String[]>();
	ArrayList<String[]> datas = new ArrayList<String[]>(); 
	
		SimpleCSVReader files = new SimpleCSVReader();
		String[] array = retrieveDataset(originalDatasetName,data);
		String names = null;
		
		int x =0;
		int value = 0;
				for(String y:array){
					if(filterColumnName.equals(y)){
						value=x;
					}
					x++;
				}
	
		for(String[] z:files.load(names)){
			if(filterValue.equals(z[value])){
				datas.add(z);
			}
		}
		registerDataset(newDatasetName,names);
	
		return 1;
	}
	
	
	
	public ArrayList<String[]> getDatasetProjection(String datasetName,ArrayList<String> attributeNames) {
			String[] attNames = null;
			ArrayList<String[]> attr = new ArrayList<String[]>();
			for(String[] k :attr ){
				attr.add(attNames);
				if(k == null){
					return null;
				}
			}	
			String[] array0 = null;
			Arrays.asList(array0);
			return null;
	}

	 
}
