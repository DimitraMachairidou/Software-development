package server;

import java.util.ArrayList;

public class DatasetManagerFactory {

	public DatasetManagerFactory(String className,String datasetName, String canonicalPath,ArrayList<String []> data,String originalDatasetName,String newDatasetName, String filterColumnName, String filterValue,ArrayList<String> attributeNames) {
		
	}
	
	public IDatasetManager create(String className,String datasetName, String canonicalPath,ArrayList<String []> data,String originalDatasetName,String newDatasetName, String filterColumnName, String filterValue,ArrayList<String> attributeNames) {
		switch(className) {
			case "DatasetManager":  DatasetManagerFactory newDatasetManagerFactory = new DatasetManagerFactory(filterValue, filterValue, filterValue, data, filterValue, filterValue, filterValue, filterValue, attributeNames) ; 
				
				return newDatasetManagerFactory.create(canonicalPath, newDatasetName, filterColumnName,
						data, filterValue, datasetName, className, originalDatasetName,
						attributeNames);
			default:  System.out.println("Wrong"); 
				return null;
		}

	}
}
