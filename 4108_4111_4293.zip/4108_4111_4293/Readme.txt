Dimitra Machairidou A.M 4108
Vasiliki Michalopoulou A.M 4111
Anastasia Kitsiou A.M 4293

OI BIBLIOTHKES POY XRHSIMOPOIHTHIKAN EINAI :
ArrayList
HashMap 
SimpleCSVReader
RunWith
Suite
SuiteClasses
Assert.*
Test
IDatasetManager
Before
BeforeClass
ScatterChartPresenter
TableViewController
BufferedReader
IOException
FileReader
ActionEvent
EventHandler
Insets
Scene
Alert
Button
Label
TextField
AlertType
VBox
Modality
Stage
LineChart
NumberAxis
XYChart
File
Platform
FXML
FileChooser
DatasetManagerFactory
ScatterChart
List
SimpleStringProperty
StringProperty
ObservableValue
FXCollections
ObservableList
TableColumn
CellDataFeatures
TableView
AnchorPane
Callback
